function showView(view) {
    document.getElementById('chat').style.display = 'none';
    document.getElementById('tic-tac-toe').style.display = 'none';
    document.getElementById('chess').style.display = 'none';
    document.getElementById(view).style.display = 'block';
}

function sendMessage() {
    const message = document.getElementById('chatInput').value;
    const chatWindow = document.getElementById('chatWindow');
    const timestamp = new Date().toLocaleTimeString();
    chatWindow.innerHTML += `<div class="chat-message user"><strong>You:</strong> ${message}<span class="chat-timestamp">${timestamp}</span></div>`;
    fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message
            })
        })
        .then(response => response.json())
        .then(data => {
            const botTimestamp = new Date().toLocaleTimeString();
            chatWindow.innerHTML += `<div class="chat-message bot"><strong>Bot:</strong> ${data.response}<span class="chat-timestamp">${botTimestamp}</span></div>`;
            chatWindow.scrollTop = chatWindow.scrollHeight;
        });
}

function createTicTacToeBoard() {
    const board = Array(9).fill('');
    const boardDiv = document.getElementById('ticTacToeBoard');
    boardDiv.innerHTML = '';
    board.forEach((cell, index) => {
        const button = document.createElement('button');
        button.textContent = cell;
        button.onclick = () => makeTicTacToeMove(index);
        boardDiv.appendChild(button);
    });
}

function makeTicTacToeMove(index) {
    fetch('/tictactoe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                board: getCurrentTicTacToeBoard(),
                move: index
            })
        })
        .then(response => response.json())
        .then(data => {
            updateTicTacToeBoard(data.board);
            if (data.winner) {
                alert(`Winner: ${data.winner}`);
            }
        });
}

function getCurrentTicTacToeBoard() {
    const buttons = document.querySelectorAll('#ticTacToeBoard button');
    return Array.from(buttons).map(button => button.textContent);
}

function updateTicTacToeBoard(board) {
    const buttons = document.querySelectorAll('#ticTacToeBoard button');
    buttons.forEach((button, index) => {
        button.textContent = board[index];
    });
}

function tossCoin() {
    fetch('/cointoss')
        .then(response => response.json())
        .then(data => {
            document.getElementById('coinTossResult').textContent = `Coin Toss Result: ${data.result}`;
        });
}

createTicTacToeBoard();