from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import random
import chess

app = Flask(__name__)
CORS(app)

# Tic Tac Toe Logic
def check_winner(board):
    win_conditions = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8), 
        (0, 3, 6), (1, 4, 7), (2, 5, 8), 
        (0, 4, 8), (2, 4, 6)
    ]
    for condition in win_conditions:
        if board[condition[0]] == board[condition[1]] == board[condition[2]] and board[condition[0]] != '':
            return board[condition[0]]
    if '' not in board:
        return 'Draw'
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    response = generate_response(user_input)
    return jsonify({'response': response})

@app.route('/tictactoe', methods=['POST'])
def tic_tac_toe():
    data = request.json
    board = data.get('board')
    move = data.get('move')
    board[move] = 'X'  # Assume the user is 'X'
    
    winner = check_winner(board)
    if winner:
        return jsonify({'board': board, 'winner': winner})
    
    # Simple AI move (next empty spot)
    for i in range(len(board)):
        if board[i] == '':
            board[i] = 'O'
            break
    
    winner = check_winner(board)
    return jsonify({'board': board, 'winner': winner})

@app.route('/chess', methods=['POST'])
def chess_move():
    board_state = request.json.get('boardState')
    move = request.json.get('move')
    board = chess.Board(board_state)
    try:
        board.push_san(move)
        return jsonify({'newBoardState': board.fen(), 'valid': True})
    except:
        return jsonify({'valid': False, 'error': 'Invalid move'})

@app.route('/cointoss', methods=['GET'])
def coin_toss():
    result = random.choice(['Heads', 'Tails'])
    return jsonify({'result': result})

def generate_response(user_input):
    user_input = user_input.lower()
    if 'hi' in user_input or 'hello' in user_input:
        return "Hello! How can I help you today?"
    elif 'how are you' in user_input:
        return "I'm just a bot, but I'm doing great! How about you?"
    elif 'bye' in user_input:
        return "Goodbye! Have a great day!"
    else:
        return "I'm not sure how to respond to that. Can you try asking something else?"

if __name__ == '__main__':
    app.run(debug=True)
