# Install and load necessary packages
install.packages("readr")
install.packages("moments")
install.packages("corrplot")
library(readr)
library(moments)
library(corrplot)
library(dplyr)

# Read data from user-chosen file "pva97nk.csv"
data <- read.csv(file.choose())


# Checks for missing values
missing_values <- colSums(is.na(data))
missing_variables <- names(missing_values[missing_values > 0])

# To fill missing values with mean of the respective columns
for (var in missing_variables) {
  data[[var]][is.na(data[[var]])] <- mean(data[[var]], na.rm = TRUE)
}

# Checks for missing values again
missing_values <- colSums(is.na(data))
missing_variables <- names(missing_values[missing_values > 0])

# Skewness and kurtosis for numeric variables
numeric_data <- select_if(data, is.numeric)
skewness_values <- sapply(numeric_data, skewness)
kurtosis_values <- sapply(numeric_data, kurtosis)

# Summary of all variables
summary_data <- lapply(data, summary)

# Histogram frequency distribution plots for numeric variables
par(mfrow = c(3, 2))
for (var in names(numeric_data)) {
  hist(numeric_data[[var]], main = paste("Histogram of", var))
}

# Log values equivalent for numeric variables
log_numeric_data <- log(numeric_data)

# Correlation matrix and plot for numeric variables
correlation_matrix <- cor(numeric_data)
corrplot(correlation_matrix, method = "color")

