# Read data from user-chosen file "ToyotaCorolla.csv"
data <- read.csv(file.choose())

# View the first few rows of the data
view(data)

# Check the structure of the dataset
str(data)

# Summary statistics
summary(data)

# Build linear regression model
model <- lm(Price ~ Age + KM + FuelType + HP + MetColor + Automatic + CC + Doors + Weight, data = data)

# Summary of the model
summary(model)

# Predicted values of the response variable
predicted <- predict(model)

# Compute residuals
residuals <- resid(model)

# Plot residuals
plot(residuals, main = "Residual Plot", xlab = "Observations", ylab = "Residuals")

# Metrics for model accuracy
# Mean Absolute Error (MAE)
mae <- mean(abs(residuals))
cat("Mean Absolute Error (MAE):", mae, "\n")

# Root Mean Squared Error (RMSE)
rmse <- sqrt(mean(residuals^2))
cat("Root Mean Squared Error (RMSE):", rmse, "\n")

# R-squared value
r_squared <- summary(model)$r.squared
cat("R-squared value:", r_squared, "\n")

# Adjusted R-squared value
adj_r_squared <- summary(model)$adj.r.squared
cat("Adjusted R-squared value:", adj_r_squared, "\n")


