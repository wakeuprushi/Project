install.packages("car")

library(car) 

set.seed(1)

del<- read.csv(file.choose())
View(del)

del[1:3]

del$sched=factor(floor(del$schedtime/100))

table(del$sched)

table(del$carrier)

table(del$dest)

table(del$origin)

table(del$weather)

table(del$dayweek)

table(del$daymonth)

table(del$delay)

class(del$delay)

del$delay=recode(del$delay,"'delayed'=1;else=0")

class(del$delay)

table(del$delay)

del$dayweek=recode(del$dayweek,"c(1,7)=1;else0")

table(del$dayweek)

del=del[,c(-1,-3,-5,-6,-7,-11,-12)]
del[1:3]

n=length(del$delay)
n

n1 <- floor(0.6 * n)
n1

n2=n-n1
n2

train=sample(1:n,n1)

Xdel <- model.matrix(delay~.,data=del)[,-1]
View(Xdel)

Xdel[1:3]

xtrain <-Xdel[train,]
View(xtrain)

ytrain <- del$delay[train]
ytrain

xnew <- Xdel[-train,]
View(xnew)

ynew <- del$delay[-train]
ynew

m1 <- glm(delay ~ ., family = binomial, data = data.frame(delay = ytrain, xtrain))
summary(m1)


ptest <- predict(m1,newdata=data.frame(xnew),type="response")
ptest

dnew=data.frame(ynew,ptest)
View(dnew)

plot(ynew~ptest)
gg1=floor(ptest+0.5)
gg1

ttt=table(ynew,gg1)
ttt
ttt[1,2]
ttt[2,1]

error=(ttt[1,2]+ttt[2,1])/n2

gg2=floor(ptest+0.7)
ttt=table(ynew,gg2)
ttt

error=(ttt[1,2]+ttt[2,1])/n2
error

bb <- cbind(ptest, ynew)
bb

bb1=bb[order(ptest,decreasing=TRUE),]
bb1

xbar=mean(ynew)
xbar

axis=dim(n2)
ax=dim(n2)
ay=dim(n2)
axis[1]=1
ax[1]=xbar
ay[1]=bb1[1,2]

for (i in 2:n2) {
  axis[i]=i
  ax[i]=xbar*i
  ay[i]=ay[i-1]+bb1[i,2]
}

aaa <- cbind(bb1[,1], bb1[,2], ay, ax)
aaa[1:100,]

