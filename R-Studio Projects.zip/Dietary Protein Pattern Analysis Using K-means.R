# Load required libraries
library(tidyverse)
library(cluster)
library(ggplot2)

# Read the dataset "protein.csv" 
data <- read.csv(file.choose())

# Select the relevant columns for clustering (protein intake from red and white meat)
features <- data[, c("RedMeat", "WhiteMeat")]

# Standardize the features
scaled_features <- scale(features)

# Perform k-means clustering with different values of k
k_values <- c(2, 3, 4, 5)  # You can adjust this list as needed

# Function to perform k-means clustering and plot the clusters
perform_clustering <- function(k) {
  # Perform k-means clustering
  kmeans_result <- kmeans(scaled_features, centers = k, nstart = 25)
  
  # Add cluster labels to the dataset
  data$cluster <- as.factor(kmeans_result$cluster)
  
  # Plot the clusters
  ggplot(data, aes(x = RedMeat, y = WhiteMeat, color = cluster)) +
    geom_point() +
    labs(title = paste("K-Means Clustering (k =", k, ")"),
         x = "Protein intake from Red Meat",
         y = "Protein intake from White Meat",
         color = "Cluster") +
    theme_minimal()
}

# Plot clusters for different values of k
plots <- lapply(k_values, perform_clustering)

# Show the plots
plots[[1]]  # For k = 2
plots[[2]]  # For k = 3
plots[[3]]  # For k = 4
plots[[4]]  # For k = 5
