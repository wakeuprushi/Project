# Read the dataset
toyota <- read.csv(file.choose())

# View the dataset
View(toyota)

# Check the class of the dataset
class(toyota)

# Display rows 2 to 4
toyota[2:4,]

# Display the first few rows
head(toyota)

# Display the structure of the dataset
str(toyota)

# Summary statistics
summary(toyota)

# Histogram of the Weight variable
hist(toyota$Weight)

# Convert FuelType to a factor and create a numeric version
toyota$FuelTypea <- as.numeric(factor(toyota$FuelType))

# View the dataset after modification
View(toyota)

# Display rows 2 to 4 after modification
toyota[2:4,]

# Remove the 4th column and view the modified dataset
auto <- toyota[-4]
View(auto)

# Remove the 9th column and view the modified dataset
auto <- toyota[-9]
View(auto)

# Display rows 2 to 4 after each modification
auto[2:4,]

# Scatter plot and correlation for Price vs Age
plot(Price ~ Age, data = auto)
cor(auto$Price, auto$Age)

# Scatter plot and correlation for Price vs KM
plot(Price ~ KM, data = auto)
cor(auto$Price, auto$KM)

# Scatter plot and correlation for Price vs HP
plot(Price ~ HP, data = auto)
cor(auto$Price, auto$HP)

# Scatter plot and correlation for Price vs MetColor
plot(Price ~ MetColor, data = auto)
cor(auto$Price, auto$MetColor)

# Scatter plot and correlation for Price vs Automatic
plot(Price ~ Automatic, data = auto)
cor(auto$Price, auto$Automatic)

# Scatter plot and correlation for Price vs CC
plot(Price ~ CC, data = auto)
cor(auto$Price, auto$CC)

# Scatter plot and correlation for Price vs Doorsa
plot(Price ~ Doorsa, data = auto)
cor(auto$Price, auto$Doorsa)

# Scatter plot and correlation for Price vs Weight
plot(Price ~ Weight, data = auto)
cor(auto$Price, auto$Weight)

# Linear regression model using all variables
m1 <- lm(Price ~ ., data = auto)
summary(m1)

# Linear regression model using only Age
m2 <- lm(Price ~ Age, data = auto)
summary(m2)

# Linear regression model using Age, Doors, and KM
m3 <- lm(Price ~ Doors + Age + KM, data = auto)
summary(m3)

# Set seed for reproducibility
set.seed(1)

# Split data into training and testing sets
n <- length(auto$Price)
n1 <- 1000
n2 <- n - n1
train <- sample(1:n, n1)

# Fit linear regression model using all variables
lmmodel1 <- lm(Price ~ ., data = auto)
print(summary(lmmodel1))

# Make predictions
Pred1 <- predict(lmmodel1)

# Plot predictions vs actual prices
plot(Pred1, pch = 15, col = 'red')

