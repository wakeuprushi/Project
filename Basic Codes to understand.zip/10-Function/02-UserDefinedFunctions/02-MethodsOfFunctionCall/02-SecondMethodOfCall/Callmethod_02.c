#include <stdio.h> 
int main(int argc, char* argv[], char* envp[])
{
	//function prototypes
	
	void display_information_rlk(void);
	void Function_Country_rlk(void);
	
	//code
	
	display_information_rlk(); 
	Function_Country_rlk(); 
	
	return(0);
}

void display_information_rlk(void)
{
	//function prototypes
	void Function_My_rlk(void);
	void Function_Name_rlk(void);
	
	void Function_Is_rlk(void);
	void Function_FirstName_rlk(void);
	void Function_MiddleName_rlk(void);
	void Function_Surname_rlk(void);
	void Function_OfAMC_rlk(void);
	
	//code
	


	Function_My_rlk();
	
	Function_Name_rlk();
	
	Function_Is_rlk();
	
	Function_FirstName_rlk();
	
	Function_MiddleName_rlk();
	
	Function_Surname_rlk();
	
	Function_OfAMC_rlk();
}
void Function_My_rlk(void)
{
	//code
	
	printf("\n\n");
	
	printf("  My");
}
void Function_Name_rlk(void)
{
	//code
	
	printf("\n\n");
	
	printf("  Name");
}
void Function_Is_rlk(void)
{
	//code
	printf("\n\n");
	printf("  Is");
}
void Function_FirstName_rlk(void)
{
	
	printf("\n\n");
	
	printf("  RUSHIKESH");
}
void Function_MiddleName_rlk(void)
{
	
	printf("\n\n");
	
	printf("  LAXMIKANT");
}
void Function_Surname_rlk(void)
{
	
	printf("\n\n");
	
	printf("  KORDE");
}
void Function_OfAMC_rlk(void)
{
	
	printf("\n\n");
	
	printf("  Of ASTROMEDICOMP");
}
void Function_Country_rlk(void)
{
	
	printf("\n\n");
	
	printf("  I live In INDIA.");
	
	printf("\n\n");
}

