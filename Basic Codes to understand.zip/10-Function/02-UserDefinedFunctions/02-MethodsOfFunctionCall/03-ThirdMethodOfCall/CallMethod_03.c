#include <stdio.h> 

int main(int argc, char* argv[], char* envp[])
{
	//function prototypes
	void Function_Country_rlk();

	//code
	
	Function_Country_rlk();
	return(0);
}
void Function_Country_rlk(void)
{
	// fucntion declarations
	void Function_OfAMC_rlk(void);
	
	// code
	Function_OfAMC_rlk();

	printf("\n\n");
	printf("I live In India.");
	printf("\n\n");
}
void Function_OfAMC_rlk(void)
{
	// function declarations
	void Function_Surname_rlk(void);
	// code
	Function_Surname_rlk();
	printf("\n\n");
	printf("Of ASTROMEDICOMP");
}
void Function_Surname_rlk(void)
{
	// function declarations
	void Function_MiddleName_rlk(void);
	// code
	Function_MiddleName_rlk();
	printf("\n\n");
	printf("KORDE");
}
void Function_MiddleName_rlk(void)
{
	// function declarations
	void Function_FirstName_rlk(void);
	// code
	Function_FirstName_rlk();
	printf("\n\n");
	printf("LAXMIKANT");
}
void Function_FirstName_rlk(void)
{
	// function declarations
	void Function_Is_rlk(void);
	// code
	Function_Is_rlk();
	printf("\n\n");
	printf("RUSHIKESH");
}
void Function_Is_rlk(void)
{
	// function declarations
	void Function_Name_rlk(void);
	//code
	Function_Name_rlk();
	printf("\n\n");
	printf("Is");
}
void Function_Name_rlk(void)
{
	// function declarations
	
	void Function_My_rlk(void);
	//code
	Function_My_rlk();

	printf("\n\n");
	printf("Name");
}

void Function_My_rlk(void)
{
	//code
	printf("\n\n");
	printf("My");
}

