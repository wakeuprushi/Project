#include <stdio.h> 


void main(void)
{
	//code

	printf("Hello World 'RUSHIKESH KORDE' !!!\n"); 
}
