#include <stdio.h> 

int main(int argc)
{
	//code

	printf("Hello World 'RUSHIKESH KORDE' !!!\n");
}
