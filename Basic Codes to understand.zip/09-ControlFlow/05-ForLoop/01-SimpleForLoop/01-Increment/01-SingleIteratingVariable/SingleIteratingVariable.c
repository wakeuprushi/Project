#include <stdio.h>

int main(void)
{
	//variable declarations
	
	int rlk_i;
	
	//code
	
	printf("\n\n");
	
	printf("Printing Digits 1 to 10 : \n\n");
	
	for (rlk_i = 1; rlk_i <= 10; rlk_i++)
		{
		   printf("\t%d\n", rlk_i);
		}
	
	printf("\n\n");
	
	return(0);

}