#include<stdio.h>
int main(void)
{
	//variable Declaration
	int rlk_a, rlk_b, rlk_p;

	//code
	rlk_a = 9;
	rlk_b = 30;
	rlk_p = 30;

	printf("\n\n");

	if (rlk_a < rlk_b)
	{
		printf("A is Less Than B!!!!\n\n");

	}

	if (rlk_b != rlk_p)
	{
		printf("B Is Not Equal To P!!!\n\n\n");

	}

	printf("Both Comparison Have een Done");

  return(0);
}
