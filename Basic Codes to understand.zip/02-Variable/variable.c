#include<stdio.h>

int main(void)
{
	//variable declaration
	int rlk_i = 5;
	float rlk_f = 3.9f;
	double rlk_d = 8.041997;
	char rlk_c = 'A';

	//code
	printf("\n\n");

	printf("i = %d\n", rlk_i);
	printf("f = %f\n",rlk_f);
	printf("d = %lf\n", rlk_d);
	printf("c = %c\n", rlk_c);

	printf("\n\n");

	rlk_i = 43;
	rlk_f = 6.54;
	rlk_d = 22.294;
	rlk_c = 'R';


	printf("i = %d\n", rlk_i);
	printf("f = %f\n", rlk_f);
	printf("d = %lf\n", rlk_d);
	printf("c = %c\n", rlk_c);

	printf("\n\n");

	return(0);




}
