# 💸 Expense Tracker (Command Line Python App)

A simple command-line Python application developed by **Rushikesh Korde** to help you track your daily expenses by category. It allows you to add, view, and store expense entries in a local JSON file.

---

## 📌 Features

- Add expenses with category, amount, and optional description.
- View all recorded expenses with total amount spent.
- Saves data persistently in a JSON file (`expenses.json`).

---

## 🛠️ Setup Instructions

### 1. Install Python

Make sure Python 3.x is installed.

- Download Python:  
  👉 [https://www.python.org/downloads/](https://www.python.org/downloads/)

Verify the installation:

```bash
python --version
```

or

```bash
python3 --version
```

---

### 2. (Optional) Create a Virtual Environment

To avoid dependency issues:

```bash
python -m venv env
```

Activate the environment:

- **Windows:**
  ```bash
  .\env\Scripts\activate
  ```
- **Mac/Linux:**
  ```bash
  source env/bin/activate
  ```

---

## 🚀 How to Run the App

1. Place the code in a file named `expense_tracker.py`.
2. Open terminal or command prompt in that directory.
3. Run the script:

```bash
python expense_tracker.py
```

---

## 📁 Project Structure

```
expense-tracker/
│
├── expense_tracker.py   # Main program
├── expenses.json        # Auto-generated file that stores your expense data
└── README.md            # This documentation file
```

---

## 🧠 Code Breakdown

### `load_expenses()`
- Loads data from `expenses.json` if it exists.
- Returns an empty list if the file is not found.

### `save_expenses(expenses)`
- Saves the current list of expenses to `expenses.json`.

### `add_expense(expenses)`
- Takes user input for:
  - `category`
  - `amount`
  - `description` (optional)
- Appends this entry to the list and saves it.

### `show_expenses(expenses)`
- Displays all expenses with category, amount, and description.
- Also shows the total amount spent.

### `main()`
- Main menu loop.
- Offers three choices:
  1. Add Expense
  2. Show Expenses
  3. Exit

---

## 💡 Example Usage

```bash
1. Add Expense
2. Show Expenses
3. Exit
Choose an option: 1
Enter category: Travel
Enter amount: 100
Description (optional): Bus fare
Expense added!
```

---

## 📌 Future Suggestions

- Add support for dates and time.
- Filter expenses by category or time range.
- Export to Excel or CSV.
- Add pie chart/graph for expense visualization.

---

## 👨‍💻 Developed By

**Rushikesh Korde**  
Made with Python and 💙