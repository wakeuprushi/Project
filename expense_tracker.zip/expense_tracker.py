import json
import os

DATA_FILE = "expenses.json"

def load_expenses():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return []

def save_expenses(expenses):
    with open(DATA_FILE, "w") as f:
        json.dump(expenses, f)

def add_expense(expenses):
    category = input("Enter category: ")
    amount = float(input("Enter amount: "))
    desc = input("Description (optional): ")
    expenses.append({"category": category, "amount": amount, "desc": desc})
    save_expenses(expenses)
    print("Expense added!\n")

def show_expenses(expenses):
    if not expenses:
        print("No expenses recorded.")
        return
    total = 0
    for e in expenses:
        print(f"{e['category']} - ₹{e['amount']} | {e['desc']}")
        total += e['amount']
    print(f"\nTotal spent: ₹{total}\n")

def main():
    expenses = load_expenses()
    while True:
        print("1. Add Expense\n2. Show Expenses\n3. Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            add_expense(expenses)
        elif choice == '2':
            show_expenses(expenses)
        elif choice == '3':
            break
        else:
            print("Invalid option.\n")

if __name__ == "__main__":
    main()
