import RPi.GPIO as GPIO
import time
from hx711 import HX711

# GPIO setup
GPIO.setmode(GPIO.BCM)
COLLISION_PIN = 17
DRIVER_AIRBAG_PIN = 23
PASSENGER_AIRBAG_PIN = 24

GPIO.setup(COLLISION_PIN, GPIO.IN)
GPIO.setup(DRIVER_AIRBAG_PIN, GPIO.OUT)
GPIO.setup(PASSENGER_AIRBAG_PIN, GPIO.OUT)

# Load cell setup for weight sensing
hx_driver = HX711(dout_pin=5, pd_sck_pin=6)
hx_passenger = HX711(dout_pin=13, pd_sck_pin=19)

def detect_collision():
    """Returns True if collision sensor is triggered."""
    return GPIO.input(COLLISION_PIN) == GPIO.HIGH

def get_weight(hx):
    """Returns weight in grams from load cell."""
    val = hx.get_weight_mean(5)
    if val < 0: val = 0
    return val

def deploy_airbag(pin):
    """Activates the relay for airbag deployment."""
    GPIO.output(pin, GPIO.HIGH)
    time.sleep(0.5)
    GPIO.output(pin, GPIO.LOW)

try:
    while True:
        if detect_collision():
            driver_weight = get_weight(hx_driver)
            passenger_weight = get_weight(hx_passenger)
            if driver_weight > 30 and passenger_weight > 30:  # Both seats occupied (>30g arbitrary threshold)
                deploy_airbag(DRIVER_AIRBAG_PIN)
                deploy_airbag(PASSENGER_AIRBAG_PIN)
                print("Both airbags deployed!")
            elif driver_weight > 30:  # Only driver
                deploy_airbag(DRIVER_AIRBAG_PIN)
                print("Driver airbag deployed!")
            elif passenger_weight > 30:  # Only passenger (rare case)
                deploy_airbag(PASSENGER_AIRBAG_PIN)
                print("Passenger airbag deployed!")
            else:
                print("No occupant detected, no airbag deployed.")
            time.sleep(3)  # Stop for 3 seconds after deployment
        time.sleep(0.1)
except KeyboardInterrupt:
    GPIO.cleanup()


