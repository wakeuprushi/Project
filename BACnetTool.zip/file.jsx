function DeviceEditor({ device, onSave }) {
    const [name, setName] = useState(device.name);
    // ... fields

    return ( <
        form onSubmit = { handleSubmit } >
        <
        label > Name: < input value = { name }
        onChange = { e => setName(e.target.value) }
        /></label > { /* object type, IP, etc */ } <
        button type = "submit" > Save < /button> <
        /form>
    );
}