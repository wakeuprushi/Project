# backend/bacnet_sim.py
from bacpypes.app import BIPSimpleApplication
from bacpypes.local.device import LocalDeviceObject
from bacpypes.object import AnalogInputObject

def create_virtual_device(config):
    dev_obj = LocalDeviceObject(
        objectName=config['name'],
        objectIdentifier=('device', config['id']),
        maxApduLengthAccepted=1024,
        segmentationSupported='segmentedBoth',
        vendorIdentifier=15
    )
    app = BIPSimpleApplication(dev_obj, config['ip'])
    ai = AnalogInputObject(
        objectIdentifier=('analogInput', 1),
        objectName='Temperature Sensor',
        presentValue=25.0,
        units='degreesCelsius'
    )
    app.add_object(ai)
    return app
