# Google Analytics Data Analysis with R and Power BI

## Description
This project connects R to Google Analytics using secure authentication, fetches key website metrics, visualizes trends in R with ggplot2, and enables advanced interactive dashboards in Power BI.

## Features
- Authenticate and access Google Analytics data in R
- Retrieve metrics such as page views and sessions
- Visualize traffic trends with ggplot2
- Export data for interactive reporting in Power BI

## Setup & Usage

1. Install R packages:

2. Authenticate and import data:

3. Visualize sessions over time:

4. Export data for Power BI:

5. Import the CSV files into Power BI to build interactive dashboards or use R/Python script connectors for live reports.


