library(googleAnalyticsR)
library(ggplot2)
library(googleAuthR)
library(gargle)
ga_auth()

my_accounts <- ga_account_list()
View(my_accounts)
start_date="2023-03-10"
end_date="2023-12-20"
df1=google_analytics(viewId=295086266,date_range=c(start_date,end_date),metrics=c("pageviews"),dimensions=c("pagePath"))
df1
df2=google_analytics(viewId =295086266,date_range = c(start_date, end_date),metrics = "sessions",dimensions = "date")
View(df2)
df2
ggplot(data=df2,aes(x=date,y=sessions))+geom_line(stat="identity") 

