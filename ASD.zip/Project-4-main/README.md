# Project-4
 Conducted research and development on Autism Spectrum Disorder utilizing machine learning and Python. Employed various machine learning models and sourced research papers from IEEE to support and enhance the study.
