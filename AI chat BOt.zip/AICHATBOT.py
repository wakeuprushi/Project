"""
AI Movie Chatbot
A conversational AI assistant for movies, built with Python and Hugging Face Transformers.

Setup:
1. Install dependencies:
   pip install flask transformers requests

2. Obtain a TMDb or OMDb API key and replace '<API_KEY>' below for real movie info.

Run:
python ai_movie_chatbot.py
Access at: http://localhost:5000/chat

"""

from flask import Flask, request, jsonify
from transformers import pipeline
import requests

app = Flask(__name__)

# Hugging Face pipeline for question answering/chat
chatbot = pipeline('conversational', model='facebook/blenderbot-400M-distill')

# Example: external movie info function (OMDb)
def get_movie_info(title):
    api_key = "<API_KEY>"  # Replace with your OMDb API key
    url = f"http://www.omdbapi.com/?t={title}&apikey={api_key}"
    resp = requests.get(url)
    if resp.status_code == 200 and resp.json().get('Response') == 'True':
        data = resp.json()
        return f"Title: {data['Title']}, Year: {data['Year']}, Plot: {data['Plot']}"
    return "Sorry, I couldn't find that movie."

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get("message")
    # First, let chatbot handle the conversation
    response = chatbot(user_input)
    bot_reply = str(response[0]['generated_text'])
    # If user asks about a specific movie, fetch info
    if "tell me about" in user_input.lower():
        movie_title = user_input.lower().replace("tell me about", "").strip()
        info = get_movie_info(movie_title)
        bot_reply += "\n" + info
    return jsonify({"reply": bot_reply})

if __name__ == '__main__':
    app.run(debug=True)
