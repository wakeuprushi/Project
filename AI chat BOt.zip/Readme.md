# AI Movie Chatbot

## Description
AI Movie Chatbot is an intelligent conversational assistant built with Python, leveraging machine learning and natural language processing to discuss and recommend movies. The chatbot can answer movie-related questions, provide movie details, recommend films, and engage users in interactive dialogue using state-of-the-art AI models and external movie databases.

## Features
- Conversational AI powered by Hugging Face’s BlenderBot model
- Connects to OMDb API for detailed movie information (title, year, plot, actors, etc.)
- Handles natural language queries and movie recommendations
- Simple Flask-based REST API backend for easy integration
- Extensible for advanced AI capabilities like personalization and sentiment analysis

## Technology Stack
- Python 3
- Flask (Web API)
- Hugging Face Transformers (`facebook/blenderbot-400M-distill` conversational model)
- OMDb API for movie data
- Requests library for HTTP calls

## Installation

1. Clone the repository:


2. Create and activate a Python virtual environment:


3. Install dependencies:


4. Obtain a free API key from [OMDb API](http://www.omdbapi.com/apikey.aspx).

5. Open the `app.py` file and replace `<API_KEY>` with your OMDb API key.

## Usage

1. Run the Flask application:


2. Send a POST request to the `/chat` endpoint with a JSON payload like:


3. The chatbot responds with conversational replies and movie details if requested.

## Example Interaction

**User:** Tell me about The Matrix  
**Bot:** Title: The Matrix, Year: 1999, Plot: When a beautiful stranger leads computer hacker Neo to a forbidding underworld... [additional chatbot reply]

## Extending the Bot

- Add personalized recommendations based on user history.
- Integrate additional movie databases or streaming services.
- Implement sentiment analysis to gauge user preferences.
- Build a front-end chat interface with React or plain JavaScript.

## License

MIT License

## Author

Your Name — your.email@example.com
